function reverseInPlace(str) {
    var words = [];
    words = str.match(/\S+/g);
    var result = "";
    for (var i = 0; i < words.length; i++) {
       result += words[i].split('').reverse().join('') + " ";
    }
    return result
  }
  console.log(reverseInPlace("abd fhe kdj"))

  //run -> E:\javascript\interview>node script.js
 //o/p=dba ehf jdk 
